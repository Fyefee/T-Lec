const AWS = require('aws-sdk');
const { v4: uuidv4 } = require("uuid");
const docClient = new AWS.DynamoDB.DocumentClient();
const dynamoDBTableName = "user"

exports.handler = async (event) => {
    let response = await createUser(JSON.parse(event.body));
    return response
};


function buildResponse(statusCode, body){
    return{
        statusCode: statusCode,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body),
    }
}

async function createUser(requestBody){
    
    if (!checkEmail(requestBody.email.substring(requestBody.email.length - 14, requestBody.email.length))) {
        return buildResponse(200, "wrong domain")
    }
    
    const findByEmailparams = {
        TableName: dynamoDBTableName,
        FilterExpression:
          "attribute_not_exists(deletedAt) AND contains(email, :email)",
        ExpressionAttributeValues: {
          ":email": requestBody.email,
        },
    }
    
    try{
        const userByEmail = await docClient.scan(findByEmailparams).promise()
        if (userByEmail.Count !== 0){
            // login
        }
        return buildResponse(200, userByEmail)
    } catch (err){
        return buildResponse(403, err)
    }
}

const checkEmail = (domain) => {
    return domain == "it.kmitl.ac.th"
}