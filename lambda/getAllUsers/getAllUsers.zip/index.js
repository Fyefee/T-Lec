const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const dynamoDBTableName = "user"

exports.handler = async (event) => {
    let response = await getUsers();
    return response
};


function buildResponse(statusCode, body){
    return{
        statusCode: statusCode,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body),
    }
}

async function getUsers(){
    const params = {
        TableName: dynamoDBTableName,
        Select: "ALL_ATTRIBUTES"
    }
    try{
        await docClient.scan(params, function(err, data) {
            if (err) {
               console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
               return buildResponse(403)
            } else {
               console.log("GetItem succeeded:", JSON.stringify(data, null, 2));
               const body = {
                    users: JSON.stringify(data, null, 2),
                }
                return buildResponse(200, body)
            }
          });
    } catch (err){
        return err
    }
}